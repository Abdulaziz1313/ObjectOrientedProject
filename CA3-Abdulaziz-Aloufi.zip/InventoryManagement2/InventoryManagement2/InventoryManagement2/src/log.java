
public class log {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		
		LoginPage loginPage = new LoginPage(null);

	}
}
